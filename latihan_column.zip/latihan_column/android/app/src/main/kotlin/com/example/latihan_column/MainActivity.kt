package com.example.latihan_column

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
